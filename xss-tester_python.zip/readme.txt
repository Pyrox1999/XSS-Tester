This program Tests a Website if it is vulnerable for XSS-injection. It puts some payloads in the page. XSS is JavaScriptcode which can attack the user. When in a internet-Forum someone writes in his comment --> <script>alert('XSS');</script>, then a pop-up-window opens with the message "XSS". That is harmless, but it Shows you, how XSS can work.

Music by Tozan
